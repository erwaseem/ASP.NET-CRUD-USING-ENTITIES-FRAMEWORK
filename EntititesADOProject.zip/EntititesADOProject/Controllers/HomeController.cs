﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EntititesADOProject.Models;

namespace EntititesADOProject.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        NareshITDbEntities _context = new NareshITDbEntities();

      
        public ActionResult Index()
        {
            var list =_context.Employees.ToList();
            return View(list);
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Employee emp)
        {
            _context.Employees.Add(emp);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult Details(int id)
        {
            var category = _context.Employees.Find(id);
            return View(category);
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
           var category= _context.Employees.Find(id);
            return View(category);
        }
        [HttpPost]
        public ActionResult Edit(Employee emp)
        {
            _context.Entry(emp).State = System.Data.Entity.EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult Delete(int id)
        {
            var category = _context.Employees.Find(id);
            _context.Employees.Remove(category);
            _context.SaveChanges();
            return RedirectToAction("Index");

        }


    }
}